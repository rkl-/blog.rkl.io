Hello skeleton project
